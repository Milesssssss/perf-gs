"""Authoritative host<->shader contract: the SINGLE source of truth for the
Gaussian primitive layout and the reusable-algorithm execution constants.

These previously lived as hand-written constants in ``buffers.py`` whose own
comment admitted *"there is no codegen bridge between Python and Slang, so these
comments are the contract."* This module replaces that convention with an
executable schema:

  * the Python constants (scalar count, gradient-channel order, offsets,
    optimizer groups, tile/cluster/radix/scan sizes) are DERIVED here, and
  * the Slang counterparts are GENERATED from the same schema
    (:func:`generate_execution_slang`, written to :data:`GENERATED_SLANG_PATH`).

``tests/test_contracts.py`` pins the derived values against the shipped layout,
checks the generated Slang is not stale, and reflects the compiled ``Gaussian3D``
struct to confirm its size matches the contract. A layout change is therefore a
one-place edit in this module that fails loudly if the two sides drift.

Kept dependency-free (pure dataclasses, no ``tomllib``/``tomli``) so it imports
on the CPU test path with no GPU or 3.11-only requirement.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

_SCALAR_COUNTS = {"float": 1, "float2": 2, "float3": 3, "float4": 4}


# --- Primitive schema -------------------------------------------------------

@dataclass(frozen=True)
class FieldSpec:
    """One field of a differentiable primitive's packed storage layout.

    ``gradients`` names the per-scalar gradient-accumulator buffers in order; its
    length equals the field's scalar count (``float3`` -> 3, ``float4`` -> 4,
    ``float`` -> 1). ``optimizer_group`` is the learning-rate group the field
    belongs to; ``moment_name`` is its Adam-moment prefix (the ``AdamState``
    struct holds ``<moment_name>_m`` / ``<moment_name>_v``), which differs from
    ``name`` for the renamed channels (``rot_quat`` -> ``rot``, ``sh0`` ->
    ``color``). ``doc`` is a short note emitted into the generated Slang struct.
    ``differentiable`` is False for fields the projection/blend read but never
    receive a gradient for (none today; present for the extension axis).
    """
    name: str                       # Slang struct field name
    dtype: str                      # "float" | "float2" | "float3" | "float4"
    gradients: tuple[str, ...]
    optimizer_group: str
    moment_name: str
    doc: str = ""
    differentiable: bool = True

    @property
    def scalar_count(self) -> int:
        return _SCALAR_COUNTS[self.dtype]


# The 3D Gaussian primitive. ORDER IS THE ABI: it defines the packed storage
# layout, the flat gradient-channel order, and the Adam channel order. Three
# spellings are load-bearing and easy to get wrong by hand (the trap this schema
# removes): the rot_quat gradients/moments use the prefix `rot` (w,x,y,z, w first
# to match the stored quaternion (w,x,y,z)); the appearance field is stored as
# `sh0` but its gradients/moments are named `color_*`; and opacity is a logit.
GAUSSIAN_FIELDS: tuple[FieldSpec, ...] = (
    FieldSpec("mean",      "float3", ("mean_x", "mean_y", "mean_z"),               "position",   "mean",
              doc="world-space position"),
    FieldSpec("log_scale", "float3", ("log_scale_x", "log_scale_y", "log_scale_z"), "scale",      "log_scale",
              doc="per-axis log scale; exp(log_scale) is the 3D gaussian scale"),
    FieldSpec("rot_quat",  "float4", ("rot_w", "rot_x", "rot_y", "rot_z"),         "rotation",   "rot",
              doc="rotation quaternion (w, x, y, z)"),
    FieldSpec("opacity",   "float",  ("opacity",),                                  "opacity",    "opacity",
              doc="pre-sigmoid opacity logit; sigmoid(opacity) is the probability"),
    FieldSpec("sh0",       "float3", ("color_r", "color_g", "color_b"),            "appearance", "color",
              doc="SH band-0 (DC) color coeff; linear RGB = 0.5 + C0*sh0"),
)

# Derived: packed scalar count + flat gradient-channel order (never declared by
# hand — computed from the schema so they cannot drift from it).
GAUSSIAN_FLOAT_COUNT: int = sum(f.scalar_count for f in GAUSSIAN_FIELDS)
GRAD_SCALAR_COMPONENTS: tuple[str, ...] = tuple(
    g for f in GAUSSIAN_FIELDS for g in f.gradients
)
# AdamState is AoS with two moments (m, v) per optimized field.
ADAM_STATE_FLOAT_COUNT: int = sum(
    2 * f.scalar_count for f in GAUSSIAN_FIELDS if f.differentiable
)


def gaussian_field_offsets() -> dict[str, int]:
    """Field name -> its first scalar offset into the packed layout."""
    offsets: dict[str, int] = {}
    cur = 0
    for f in GAUSSIAN_FIELDS:
        offsets[f.name] = cur
        cur += f.scalar_count
    return offsets


def gaussian_numpy_dtype() -> np.dtype:
    """Structured NumPy dtype for one packed Gaussian3D (56 bytes, tightly packed
    like the Slang struct). Named-field access (``arr["mean"]``) replaces the
    hand-coded scalar-offset slices in CPU packing, PLY export, and densify
    readback, so a layout change is a one-place edit in this schema."""
    fields: list = []
    for f in GAUSSIAN_FIELDS:
        if f.scalar_count == 1:
            fields.append((f.name, np.float32))
        else:
            fields.append((f.name, np.float32, (f.scalar_count,)))
    return np.dtype(fields)


def optimizer_groups() -> dict[str, tuple[int, int]]:
    """Optimizer group -> (first scalar offset, scalar count) in the flat layout."""
    groups: dict[str, tuple[int, int]] = {}
    cur = 0
    for f in GAUSSIAN_FIELDS:
        groups[f.optimizer_group] = (cur, f.scalar_count)
        cur += f.scalar_count
    return groups


# Projected 2D gradient seeds (Gaussian projection-backward bridge): summed by
# the blend backward, consumed once per gaussian by projection_backward.slang.
GRAD_2D_SEED_COMPONENTS: tuple[str, ...] = (
    "mean2d_x", "mean2d_y",
    "cov2d_a", "cov2d_b", "cov2d_c",
    "comp",   # Mip-Splatting: dL/d(opacity_compensation)
)

# Structure-aware densification (SAD-GS) multiview accumulators (SoA uint):
# n_high/n_low are scalar per-gaussian view counts (split GATE); max_x/y/z are
# per-axis max eta (split FACTOR). Names match score_structure_aware.slang.
ETA_ACCUM_COMPONENTS: tuple[str, ...] = (
    "n_high", "n_low",
    "max_x", "max_y", "max_z",
)


# --- Algorithm execution constants ------------------------------------------

@dataclass(frozen=True)
class ExecutionContract:
    """Reusable-algorithm constants shared host<->shader. Independent inputs are
    fields; dependent values are derived properties (never stored twice)."""
    tile_size: int = 16              # tile_binned/*.slang, densify/score_forward.slang
    cluster_size: int = 128          # rasterize/cluster_cull.slang
    radix_digits: int = 256          # device_radix_sort.slang D_DIM / 8-bit radix
    radix_keys_per_thread: int = 8   # device_radix_sort.slang KEYS_PER_THREAD
    radix_passes: int = 8            # 64-bit key / 8-bit digit
    scan_block_size: int = 1024      # common/scan.slang SCAN_BLOCK_SIZE
    raster_bucket_size: int = 32     # rasterize/tile_binned/checkpoint.slang

    @property
    def radix_part_size(self) -> int:
        """Sort partition = threads-per-block * keys-per-thread (derived)."""
        return self.radix_digits * self.radix_keys_per_thread

    @property
    def radix_global_hist_size(self) -> int:
        """One ``radix_digits``-wide region per pass (derived)."""
        return self.radix_digits * self.radix_passes


EXECUTION = ExecutionContract()

# Flat aliases matching the historical buffers.py constant names, so existing
# importers keep working after the definitions moved here.
TILE_SIZE = EXECUTION.tile_size
CLUSTER_SIZE = EXECUTION.cluster_size
RADIX_PART_SIZE = EXECUTION.radix_part_size
RADIX_GLOBAL_HIST_SIZE = EXECUTION.radix_global_hist_size
SCAN_BLOCK_SIZE = EXECUTION.scan_block_size
RASTER_BUCKET_SIZE = EXECUTION.raster_bucket_size


# --- Slang generation -------------------------------------------------------

GENERATED_SLANG_PATH = "shaders/generated/execution_contract.slang"
GENERATED_PRIMITIVE_SLANG_PATH = "shaders/generated/gaussian_types.slang"

_SLANG_BANNER = (
    "// DO NOT EDIT. Generated from src/trainer/contracts.py.\n"
    "// Regenerate with:  python -m trainer.contracts\n"
    "// Validated not-stale by tests/test_contracts.py.\n"
)


def generate_execution_slang(ex: ExecutionContract = EXECUTION) -> str:
    """Emit the Slang header of shared execution + layout constants."""
    consts = [
        ("TILE_SIZE", ex.tile_size),
        ("CLUSTER_SIZE", ex.cluster_size),
        ("RADIX_PART_SIZE", ex.radix_part_size),
        ("RADIX_DIGITS", ex.radix_digits),
        ("RADIX_KEYS_PER_THREAD", ex.radix_keys_per_thread),
        ("RADIX_PASSES", ex.radix_passes),
        ("RADIX_GLOBAL_HIST_SIZE", ex.radix_global_hist_size),
        ("SCAN_BLOCK_SIZE", ex.scan_block_size),
        ("RASTER_BUCKET_SIZE", ex.raster_bucket_size),
        ("GAUSSIAN_FLOAT_COUNT", GAUSSIAN_FLOAT_COUNT),
    ]
    lines = [_SLANG_BANNER, "#ifndef TRAINER_EXECUTION_CONTRACT",
             "#define TRAINER_EXECUTION_CONTRACT", ""]
    lines += [f"static const int CONTRACT_{name} = {val};" for name, val in consts]
    lines += ["", "#endif // TRAINER_EXECUTION_CONTRACT", ""]
    return "\n".join(lines)


def generate_primitive_slang() -> str:
    """Emit the Gaussian3D storage struct + AdamState moment struct from the
    schema. Field ORDER is the ABI (packed storage + Adam moment channel order);
    each optimized field contributes an ``<moment_name>_m`` / ``_v`` pair to
    AdamState in the same order."""
    lines = [_SLANG_BANNER, "#ifndef TRAINER_GAUSSIAN_TYPES",
             "#define TRAINER_GAUSSIAN_TYPES", "",
             "// Packed per-gaussian storage; uploaded verbatim by",
             "// trainer.buffer_io.write_gaussians (GAUSSIAN_FLOAT_COUNT float32s).",
             "struct Gaussian3D", "{"]
    for f in GAUSSIAN_FIELDS:
        suffix = f"  // {f.doc}" if f.doc else ""
        lines.append(f"    {f.dtype} {f.name};{suffix}")
    lines += ["};", "",
              "// Per-gaussian Adam first/second moments (AoS): the adam kernel loads",
              "// all m/v for one gaussian, steps, writes back (no atomics). One",
              "// (m, v) pair per optimized field, in Gaussian3D field order.",
              "struct AdamState", "{"]
    for f in GAUSSIAN_FIELDS:
        if not f.differentiable:
            continue
        lines.append(f"    {f.dtype} {f.moment_name}_m;")
        lines.append(f"    {f.dtype} {f.moment_name}_v;")
    lines += ["};", "", "#endif // TRAINER_GAUSSIAN_TYPES", ""]
    return "\n".join(lines)


def write_generated_slang() -> list[str]:
    """Write the generated Slang headers to the repo; return their paths."""
    from pathlib import Path

    repo = Path(__file__).resolve().parents[2]
    written = []
    for rel, text in ((GENERATED_SLANG_PATH, generate_execution_slang()),
                      (GENERATED_PRIMITIVE_SLANG_PATH, generate_primitive_slang())):
        out = repo / rel
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(text, encoding="utf-8")
        written.append(str(out))
    return written


if __name__ == "__main__":
    for _p in write_generated_slang():
        print(f"wrote {_p}")
